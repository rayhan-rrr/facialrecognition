<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="col-md-12">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissable" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissable" role="alert">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <!-- <?php echo e(__('You are logged in!')); ?> -->
                    <?php if(!$user->image_file1): ?>
                        <h3>Please upload your photo. Using this photo the system will recognize you.</h3>
                    <?php else: ?>
                        <?php if(!$user->image_file2 || !$user->image_file3): ?>
                            <h2>Add another image to improve recognition</h2>
                           
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if(!$user->image_file3): ?>
                        <form method="POST" action="<?php echo e(route('upload.base')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="col-md-7 float-left">
                                <div id="camera"></div>
                            </div>

                            <!--FOR THE SNAPSHOT-->
                            
                            <div class="col-md-5 float-left">
                                <h4>Your Captured Photo:</h4>
                                <br>
                                <p class="col-md-9 col-md-offset-3" id="snapShot"></p>
                            </div>
                            <br>
                            <div class="clearfix"></div>
                            <div class="col-md-12 text-center">
                                <button type="button" class="btn btn-danger btn-sm" id="btPic" onclick="takeSnapShot()"> Capture Photo</button>
                                <input type="hidden" name="capured_image" id="capured_image">
                                <br>
                                <br>
                                <button type="submit" class="btn btn-primary submitbtn" style="display: none;">Upload Photo</button>
                            </div>
                        </form>
                    <?php endif; ?>
                    
                    

                    <div class="col-md-12">
                        <h4>Capture and upload your photo to varify yourself</h4>
                        <form method="POST" action="<?php echo e(route('upload.varify')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="col-md-7 float-left">
                                <div id="camera"></div>
                            </div>

                            <!--FOR THE SNAPSHOT-->
                            
                            <div class="col-md-5 float-left">
                                <h4>Your Captured Photo:</h4>
                                <br>
                                <p class="col-md-9 col-md-offset-3" id="snapShot"></p>
                            </div>
                            <br>
                            <div class="clearfix"></div>
                            <div class="col-md-12 text-center">
                                <button type="button" class="btn btn-danger btn-sm" id="btPic" onclick="takeSnapShot()"> Capture Photo</button>
                                <input type="hidden" name="capured_image" id="capured_image">
                                <br>
                                <br>
                                <button type="submit" class="btn btn-primary submitbtn" style="display: none;">Upload Photo</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // CAMERA SETTINGS.
    Webcam.set({
        width: 400,
        height: 350,
        image_format: 'png',
        jpeg_quality: 100
    });
    Webcam.attach('#camera');

    // SHOW THE SNAPSHOT.
    takeSnapShot = function () {
        Webcam.snap(function (data_uri) {
            $("#capured_image").val(data_uri);
            document.getElementById('snapShot').innerHTML = 
                '<img src="' + data_uri + '" width="290px" height="250" />';

            $(".submitbtn").show();
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Rubel/Documents/facialrecognition/facialrecognition/resources/views/home.blade.php ENDPATH**/ ?>